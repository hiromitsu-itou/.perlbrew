#undef PERL_CORE
#include "core_or_not.inc"
