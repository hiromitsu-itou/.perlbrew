ccflags="$ccflags -X18"
